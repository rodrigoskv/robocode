package robocode.trainer;

import java.io.IOException;
import java.util.Arrays;

public class TrainerMain {

    public static void main(String[] args) {
        Population population = new Population();
        RobocodeFitnessEvaluator evaluator = new RobocodeFitnessEvaluator();

        Genome globalBest = null;
        double globalBestFitness = Double.NEGATIVE_INFINITY;

        try {
            for (int gen = 1; gen <= Config.GENERATIONS; gen++) {
                System.out.println("===== Geração " + gen + " =====");

                for (Genome g : population.getGenomes()) {
                    double fitness = evaluator.evaluate(g);
                    g.fitness = fitness;
                    System.out.println("  Fitness: " + fitness);
                }

                Arrays.sort(population.getGenomes());
                Genome bestGen = population.getGenomes()[0];

                System.out.println(">> Melhor da geração " + gen +
                        " | Fitness = " + bestGen.fitness);

                if (bestGen.fitness > globalBestFitness) {
                    globalBestFitness = bestGen.fitness;

                    globalBest = bestGen.copy();

                    RobocodeFitnessEvaluator.writeGenomeToWeightsFile(globalBest, Config.WEIGHTS_FILE_BEST);
                    System.out.println(">> Novo melhor GLOBAL! Fitness = " + globalBestFitness);
                }

                population.evolve();
            }

            System.out.println("=== Treino finalizado. Melhor fitness GLOBAL: " + globalBestFitness);

            if (globalBest != null) {
                RobocodeFitnessEvaluator finalEval = new RobocodeFitnessEvaluator();
                finalEval.evaluate(globalBest);
                finalEval.close();

                System.out.println("Pesos do melhor genoma gravados em: " + Config.WEIGHTS_FILE);
            } else {
                System.out.println("Nenhum genoma avaliado, nada para salvar.");
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            evaluator.close();
        }
    }
}
