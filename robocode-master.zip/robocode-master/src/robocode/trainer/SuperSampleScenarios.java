package robocode.trainer;

public final class SuperSampleScenarios {

    private SuperSampleScenarios() {}

    public static final String ONE_VS_SUPER_BOXBOT =
            "supersample.SuperBoxBot";

    public static final String ONE_VS_SUPER_RAMFIRE =
            "supersample.SuperRamFire";

    public static final String ONE_VS_SUPER_SPINBOT =
            "supersample.SuperSpinBot";

    public static final String DODGE_TRACKERS =
            "supersample.SuperTrackFire," +
                    "supersample.SuperTracker";


    public static final String MELEE_LIGHT =
            "supersample.SuperBoxBot," +
                    "supersample.SuperRamFire," +
                    "supersample.SuperSpinBot";


    public static final String MELEE_HEAVY =
            "supersample.SuperBoxBot," +
                    "supersample.SuperRamFire," +
                    "supersample.SuperSpinBot," +
                    "supersample.SuperTrackFire," +
                    "supersample.SuperTracker," +
                    "supersample.SuperCorners," +
                    "supersample.SuperWalls";


    public static final String[] TRAINING_SCENARIOS = {
            ONE_VS_SUPER_BOXBOT,
            ONE_VS_SUPER_RAMFIRE,
            ONE_VS_SUPER_SPINBOT,
            DODGE_TRACKERS,
            MELEE_LIGHT
    };


    public static final String ACTIVE_SCENARIO = MELEE_HEAVY;
}
